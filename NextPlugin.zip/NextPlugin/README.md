# NextPlugin

Plugin para servidores **Spigot, Paper y Purpur para Minecraft 26.1, 26.2 y 26.3** que añade el comando `/next`.

## Comandos

| Comando | Qué hace |
|---|---|
| `/next <jugador> to` | Hace explotar al jugador elegido |
| `/next <jugador> do` | Regenera al jugador: vida y comida al máximo |

Permiso: `nextplugin.use` (por defecto, solo operadores).

## Configuración

`plugins/NextPlugin/config.yml`: potencia de la explosión, si rompe bloques, si provoca fuego, si mata siempre al jugador y todos los mensajes.

## Compilar

Requiere Java 25 y Maven:

```
mvn package
```

El `.jar` queda en `target/NextPlugin-1.0.0.jar`. Cópialo a la carpeta `plugins/` de tu servidor.

## Licencia

MIT
