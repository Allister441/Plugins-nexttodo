# Ficha lista para CurseForge

Crea el proyecto en: https://www.curseforge.com/minecraft/bukkit-plugins → **Create a project**
(Los proyectos nuevos pasan una revisión antes de ser públicos.)

## Datos del proyecto

| Campo | Valor |
|---|---|
| Nombre | NextPlugin |
| Slug | nextplugin |
| Resumen (máx. 250 caracteres) | Comando /next: haz explotar a un jugador (to) o regénéralo con vida y comida al máximo (do). Spigot, Paper y Purpur. |
| Categoría principal | Admin Tools |
| Categoría secundaria | Fun |
| Licencia | MIT |
| Código fuente | https://github.com/Allister441/NextPlugin |
| Issues | https://github.com/Allister441/NextPlugin/issues |

## Archivo a subir

| Campo | Valor |
|---|---|
| Archivo | `target/NextPlugin-1.0.0.jar` (el .jar, no el .zip del proyecto) |
| Nombre visible | NextPlugin 1.0.0 |
| Tipo de release | Release |
| Versiones de juego | 26.1, 26.2, 26.3 |
| Java | Java 25 (si la lista de CurseForge lo ofrece) |
| Plataformas | Bukkit / Spigot / Paper / Purpur (un solo .jar para todas) |

### Changelog
```
- Primera versión.
- /next <jugador> to: hace explotar al jugador.
- /next <jugador> do: vida y comida al máximo.
- Compatible con Spigot, Paper y Purpur 26.1 - 26.3.
```

## Descripción (pegar en el editor de CurseForge)

```
# NextPlugin

Plugin ligero con un único comando: /next.

## Comandos
- /next <jugador> to  → hace explotar al jugador elegido.
- /next <jugador> do  → regenera al jugador: vida y comida al máximo.

## Permiso
- nextplugin.use (por defecto, solo operadores)

## Compatibilidad
- Spigot, Paper y Purpur
- Minecraft 26.1, 26.2 y 26.3
- Requiere Java 25

## Configuración
En plugins/NextPlugin/config.yml puedes cambiar la potencia de la explosión,
si rompe bloques, si provoca fuego, si mata siempre al jugador y todos los mensajes.

## Instalación
1. Descarga el .jar.
2. Cópialo a la carpeta plugins/ de tu servidor.
3. Reinicia el servidor (no uses /reload).

Código fuente (MIT): https://github.com/Allister441/NextPlugin
```

## Publicación automática (opcional)
Con `.github/workflows/curseforge.yml` el .jar se sube solo a CurseForge cada vez que
creas un Release en GitHub. Necesitas:
1. Un token de API: https://authors.curseforge.com/account/api-tokens
2. En GitHub → Settings → Secrets and variables → Actions:
   - Secret `CURSEFORGE_TOKEN`: tu token.
   - Variable `CURSEFORGE_PROJECT_ID`: el ID numérico del proyecto (aparece en la página de Overview del proyecto).
