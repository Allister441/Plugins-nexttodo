# Publicar el código abierto en GitHub

## 1. Crear el repositorio
En https://github.com/new:
- Nombre: `NextPlugin`
- Visibilidad: **Public** (así el código es abierto)
- No marques "Add a README" ni licencia (ya vienen en el proyecto)

## 2. Subir el código
Desde la carpeta del proyecto:
```
git init
git add .
git commit -m "NextPlugin 1.0.0"
git branch -M main
git remote add origin https://github.com/Allister441/NextPlugin.git
git push -u origin main
```

## 3. Datos del repositorio (rueda ⚙ junto a "About")
- Descripción: Comando /next para explotar o regenerar a un jugador. Spigot, Paper y Purpur 26.1 - 26.3.
- Topics: `minecraft`, `minecraft-plugin`, `spigot`, `paper`, `purpur`, `bukkit`, `java`
- Website: el enlace de tu proyecto en CurseForge

## 4. Publicar una versión
```
git tag v1.0.0
git push origin v1.0.0
```
GitHub Actions compila el plugin y crea el Release con el `.jar` automáticamente.
Si has configurado el secreto de CurseForge, también se subirá allí (ver `curseforge/CURSEFORGE.md`).

## Licencia
El proyecto usa la licencia **MIT**: cualquiera puede ver, usar y modificar el código, siempre que conserve el aviso de copyright.
