# Guía para publicar

Logo: `assets/logo.png` (512x512, úsalo como icono en CurseForge y Modrinth), `assets/logo-1024.png` y `assets/logo.svg`.

Para CurseForge hay una ficha lista para copiar y pegar en `curseforge/CURSEFORGE.md`, y un workflow opcional en `.github/workflows/curseforge.yml` que sube el .jar automáticamente.

Compatible con Minecraft 26.1, 26.2 y 26.3 (Spigot, Paper y Purpur). Necesita Java 25 en el servidor.

## 1. Compilar
`mvn package` → `target/NextPlugin-1.0.0.jar`

## 2. GitHub
```
git init
git add .
git commit -m "NextPlugin 1.0.0"
git branch -M main
git remote add origin https://github.com/Allister441/NextPlugin.git
git push -u origin main
```
(Crea antes el repositorio vacío en github.com/new.) Opcional: crea un Release y sube el .jar.

## 3. Modrinth (modrinth.com → Create a project → Plugin)
- Nombre: NextPlugin
- Resumen: Comando /next para explotar o regenerar a un jugador.
- Categorías: Utility, Fun / Management
- Loaders: Spigot, Paper, Purpur, Bukkit
- Versión de juego: 26.1, 26.2, 26.3
- Licencia: MIT
- Sube el .jar como versión 1.0.0
- Descripción: copia el contenido de README.md

## 4. CurseForge (curseforge.com/minecraft/bukkit-plugins → Create project)
- Categoría: Bukkit Plugins → Fun / Admin Tools
- Tipo de archivo: .jar, versión de juego 26.1, 26.2, 26.3
- Licencia: MIT
- Descripción: copia el contenido de README.md
- Los proyectos nuevos pasan una revisión antes de aparecer públicamente.
