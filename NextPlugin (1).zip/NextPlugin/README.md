# NextPlugin

![NextPlugin](assets/logo.png)

![Licencia MIT](https://img.shields.io/badge/licencia-MIT-green)
![Minecraft](https://img.shields.io/badge/Minecraft-26.1%20%7C%2026.2%20%7C%2026.3-brightgreen)
![Plataformas](https://img.shields.io/badge/Spigot%20%7C%20Paper%20%7C%20Purpur-orange)
![Java](https://img.shields.io/badge/Java-25-blue)

Plugin de código abierto para servidores **Spigot, Paper y Purpur** (Minecraft 26.1, 26.2 y 26.3) que añade el comando `/next`.

## Comandos

| Comando | Qué hace |
|---|---|
| `/next <jugador> to` | Hace explotar al jugador elegido |
| `/next <jugador> do` | Regenera al jugador: vida y comida al máximo |

Permiso: `nextplugin.use` (por defecto, solo operadores).

## Instalación

1. Descarga el `.jar` desde la sección [Releases](../../releases).
2. Cópialo a la carpeta `plugins/` de tu servidor.
3. Reinicia el servidor (no uses `/reload`).

## Configuración

`plugins/NextPlugin/config.yml`: potencia de la explosión, si rompe bloques, si provoca fuego, si mata siempre al jugador y todos los mensajes.

## Compilar

Requiere Java 25 y Maven:

```
mvn package
```

El `.jar` queda en `target/NextPlugin-1.0.0.jar`.

## Contribuir

Las contribuciones son bienvenidas. Lee [CONTRIBUTING.md](CONTRIBUTING.md) antes de abrir un Pull Request.

## Licencia

[MIT](LICENSE): puedes usar, modificar y redistribuir el código libremente.
