# Cómo contribuir

¡Gracias por querer mejorar NextPlugin!

## Reportar errores o proponer ideas
Abre un [Issue](../../issues/new/choose) con la plantilla correspondiente. Indica siempre tu versión de Minecraft, el software del servidor (Spigot, Paper o Purpur) y la versión del plugin.

## Enviar código
1. Haz un fork del repositorio y crea una rama: `git checkout -b mi-mejora`
2. Haz tus cambios. Mantén el código sencillo y compatible con Spigot, Paper y Purpur (usa solo la API de Spigot).
3. Comprueba que compila: `mvn package` (Java 25).
4. Abre un Pull Request explicando qué cambia y por qué.

Al contribuir aceptas que tu código se publique bajo la licencia MIT del proyecto.
