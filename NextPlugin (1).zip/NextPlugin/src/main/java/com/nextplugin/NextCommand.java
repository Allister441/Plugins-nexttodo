package com.nextplugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NextCommand implements CommandExecutor, TabCompleter {

    private final NextPlugin plugin;

    public NextCommand(NextPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("nextplugin.use")) {
            sender.sendMessage(msg("messages.no-permission", null));
            return true;
        }
        if (args.length != 2) {
            sender.sendMessage(msg("messages.usage", null));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(msg("messages.player-not-found", null));
            return true;
        }

        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "to" -> {
                explode(target);
                sender.sendMessage(msg("messages.exploded", target));
            }
            case "do" -> {
                heal(target);
                sender.sendMessage(msg("messages.healed", target));
                if (!sender.equals(target)) {
                    target.sendMessage(msg("messages.healed-target", target));
                }
            }
            default -> sender.sendMessage(msg("messages.usage", null));
        }
        return true;
    }

    private void explode(Player target) {
        Location loc = target.getLocation();
        float power = (float) plugin.getConfig().getDouble("explosion.power", 4.0);
        boolean fire = plugin.getConfig().getBoolean("explosion.set-fire", false);
        boolean blocks = plugin.getConfig().getBoolean("explosion.break-blocks", false);

        loc.getWorld().createExplosion(loc, power, fire, blocks);

        if (plugin.getConfig().getBoolean("explosion.kill-player", true) && !target.isDead()) {
            target.setHealth(0.0);
        }
    }

    private void heal(Player target) {
        AttributeInstance maxHealth = target.getAttribute(Attribute.MAX_HEALTH);
        target.setHealth(maxHealth != null ? maxHealth.getValue() : 20.0);
        target.setFoodLevel(20);
        target.setSaturation(20f);
        target.setExhaustion(0f);
        target.setFireTicks(0);
    }

    private String msg(String path, Player player) {
        String text = plugin.getConfig().getString(path, "");
        if (player != null) {
            text = text.replace("%player%", player.getName());
        }
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("nextplugin.use")) return out;
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        } else if (args.length == 2) {
            for (String s : List.of("to", "do")) {
                if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
            }
        }
        return out;
    }
}
