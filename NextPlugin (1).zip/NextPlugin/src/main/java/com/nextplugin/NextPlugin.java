package com.nextplugin;

import org.bukkit.plugin.java.JavaPlugin;

public final class NextPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        NextCommand handler = new NextCommand(this);
        var command = getCommand("next");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        getLogger().info("NextPlugin activado.");
    }

    @Override
    public void onDisable() {
        getLogger().info("NextPlugin desactivado.");
    }
}
